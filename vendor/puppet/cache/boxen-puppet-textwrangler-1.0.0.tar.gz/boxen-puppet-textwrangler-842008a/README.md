# TextWrangler

Installs [TextWrangler](http://www.barebones.com/products/textwrangler/).

A free text editor from Bare Bones.

## Usage:

``` puppet
include textwrangler
```

**Note**: Right now this does not install cmd tools so you will have to run that from the app menu on your own. 
